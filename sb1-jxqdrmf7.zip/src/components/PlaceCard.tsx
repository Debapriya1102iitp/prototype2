import React from 'react';
import { MapPin, Clock, Phone, Globe } from 'lucide-react';
import { ReligiousPlace } from '../types';

interface PlaceCardProps {
  place: ReligiousPlace;
  onSelect: (place: ReligiousPlace) => void;
}

export default function PlaceCard({ place, onSelect }: PlaceCardProps) {
  const categoryColors = {
    temple: 'orange',
    mosque: 'green',
    gurdwara: 'blue',
    church: 'purple'
  };

  const color = categoryColors[place.category];

  return (
    <div
      onClick={() => onSelect(place)}
      className="bg-white rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer transform hover:-translate-y-1 overflow-hidden"
    >
      <div className="relative h-48 overflow-hidden">
        <img
          src={place.image}
          alt={place.name}
          className="w-full h-full object-cover transition-transform duration-300 hover:scale-110"
        />
        <div className={`absolute top-4 left-4 px-3 py-1 rounded-full text-white text-sm font-medium ${
          color === 'orange' ? 'bg-orange-500' :
          color === 'green' ? 'bg-green-500' :
          color === 'blue' ? 'bg-blue-500' : 'bg-purple-500'
        }`}>
          {place.category.charAt(0).toUpperCase() + place.category.slice(1)}
        </div>
      </div>

      <div className="p-6">
        <h3 className="text-xl font-bold text-gray-800 mb-2">{place.name}</h3>
        
        <div className="flex items-center text-gray-600 mb-2">
          <MapPin className="w-4 h-4 mr-2" />
          <span className="text-sm">{place.location.city}, {place.location.state}</span>
        </div>

        <div className="flex items-center text-gray-600 mb-3">
          <Clock className="w-4 h-4 mr-2" />
          <span className="text-sm">{place.timings.weekdays}</span>
        </div>

        <p className="text-gray-700 text-sm mb-4 line-clamp-3">
          {place.about.substring(0, 120)}...
        </p>

        <div className="flex items-center justify-between">
          <div className="flex space-x-2">
            {place.contact?.phone && (
              <div className="p-2 bg-gray-100 rounded-lg">
                <Phone className="w-4 h-4 text-gray-600" />
              </div>
            )}
            {place.contact?.website && (
              <div className="p-2 bg-gray-100 rounded-lg">
                <Globe className="w-4 h-4 text-gray-600" />
              </div>
            )}
          </div>
          
          <button className={`px-4 py-2 rounded-lg text-white text-sm font-medium transition-colors ${
            color === 'orange' ? 'bg-orange-500 hover:bg-orange-600' :
            color === 'green' ? 'bg-green-500 hover:bg-green-600' :
            color === 'blue' ? 'bg-blue-500 hover:bg-blue-600' : 'bg-purple-500 hover:bg-purple-600'
          }`}>
            View Details
          </button>
        </div>
      </div>
    </div>
  );
}