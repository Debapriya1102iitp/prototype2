import React from 'react';

interface CategoryCardProps {
  category: {
    id: string;
    name: string;
    icon: string;
    color: string;
  };
  count: number;
  onSelect: (categoryId: string) => void;
}

export default function CategoryCard({ category, count, onSelect }: CategoryCardProps) {
  const colorClasses = {
    orange: 'from-orange-400 to-red-500 hover:from-orange-500 hover:to-red-600',
    green: 'from-green-400 to-emerald-500 hover:from-green-500 hover:to-emerald-600',
    blue: 'from-blue-400 to-indigo-500 hover:from-blue-500 hover:to-indigo-600',
    purple: 'from-purple-400 to-pink-500 hover:from-purple-500 hover:to-pink-600'
  };

  return (
    <div
      onClick={() => onSelect(category.id)}
      className={`cursor-pointer transform hover:scale-105 transition-all duration-300 bg-gradient-to-br ${colorClasses[category.color as keyof typeof colorClasses]} p-6 rounded-xl text-white shadow-lg hover:shadow-xl`}
    >
      <div className="flex items-center justify-between mb-4">
        <div className="text-4xl">{category.icon}</div>
        <div className="text-right">
          <div className="text-2xl font-bold">{count}</div>
          <div className="text-sm opacity-90">Places</div>
        </div>
      </div>
      <h3 className="text-xl font-semibold">{category.name}</h3>
      <p className="text-sm opacity-90 mt-1">Explore sacred {category.name.toLowerCase()}</p>
    </div>
  );
}