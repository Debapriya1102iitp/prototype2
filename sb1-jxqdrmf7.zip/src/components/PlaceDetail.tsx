import React from 'react';
import { MapPin, Clock, Phone, Globe, Calendar, Users, ArrowLeft, Star } from 'lucide-react';
import { ReligiousPlace } from '../types';

interface PlaceDetailProps {
  place: ReligiousPlace;
  onBack: () => void;
}

export default function PlaceDetail({ place, onBack }: PlaceDetailProps) {
  const categoryColors = {
    temple: 'orange',
    mosque: 'green',
    gurdwara: 'blue',
    church: 'purple'
  };

  const color = categoryColors[place.category];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="relative h-64 md:h-96 overflow-hidden">
        <img
          src={place.image}
          alt={place.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-40" />
        <div className="absolute top-4 left-4">
          <button
            onClick={onBack}
            className="flex items-center space-x-2 px-4 py-2 bg-white bg-opacity-90 rounded-lg text-gray-800 hover:bg-opacity-100 transition-all"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>
        </div>
        <div className="absolute bottom-6 left-6 right-6">
          <div className={`inline-block px-3 py-1 rounded-full text-white text-sm font-medium mb-4 ${
            color === 'orange' ? 'bg-orange-500' :
            color === 'green' ? 'bg-green-500' :
            color === 'blue' ? 'bg-blue-500' : 'bg-purple-500'
          }`}>
            {place.category.charAt(0).toUpperCase() + place.category.slice(1)}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-2">{place.name}</h1>
          <div className="flex items-center text-white text-lg">
            <MapPin className="w-5 h-5 mr-2" />
            <span>{place.location.city}, {place.location.state}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-4">About</h2>
              <p className="text-gray-700 leading-relaxed mb-6">{place.about}</p>
              
              <h3 className="text-xl font-semibold text-gray-800 mb-3">History</h3>
              <p className="text-gray-700 leading-relaxed">{place.history}</p>
            </div>

            {place.features && place.features.length > 0 && (
              <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Key Features</h3>
                <div className="grid grid-cols-2 gap-3">
                  {place.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="text-gray-700">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {place.festivals && place.festivals.length > 0 && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Festivals Celebrated</h3>
                <div className="grid grid-cols-2 gap-3">
                  {place.festivals.map((festival, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <Calendar className="w-4 h-4 text-purple-500" />
                      <span className="text-gray-700">{festival}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
              <h3 className="text-xl font-semibold text-gray-800 mb-4">Visit Information</h3>
              
              <div className="space-y-4">
                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <Clock className="w-5 h-5 text-blue-500" />
                    <span className="font-medium text-gray-800">Timings</span>
                  </div>
                  <div className="ml-7 text-gray-700">
                    <p className="text-sm"><strong>Weekdays:</strong> {place.timings.weekdays}</p>
                    <p className="text-sm"><strong>Weekends:</strong> {place.timings.weekends}</p>
                    {place.timings.specialDays && (
                      <p className="text-sm"><strong>Special Days:</strong> {place.timings.specialDays}</p>
                    )}
                  </div>
                </div>

                <div>
                  <div className="flex items-center space-x-2 mb-2">
                    <MapPin className="w-5 h-5 text-red-500" />
                    <span className="font-medium text-gray-800">Address</span>
                  </div>
                  <div className="ml-7 text-gray-700 text-sm">
                    <p>{place.location.address}</p>
                    <p>{place.location.city}, {place.location.state} - {place.location.pincode}</p>
                  </div>
                </div>

                {place.contact && (
                  <div>
                    <div className="flex items-center space-x-2 mb-2">
                      <Users className="w-5 h-5 text-green-500" />
                      <span className="font-medium text-gray-800">Contact</span>
                    </div>
                    <div className="ml-7 space-y-2">
                      {place.contact.phone && (
                        <div className="flex items-center space-x-2">
                          <Phone className="w-4 h-4 text-gray-500" />
                          <span className="text-gray-700 text-sm">{place.contact.phone}</span>
                        </div>
                      )}
                      {place.contact.email && (
                        <div className="flex items-center space-x-2">
                          <span className="text-gray-700 text-sm">{place.contact.email}</span>
                        </div>
                      )}
                      {place.contact.website && (
                        <div className="flex items-center space-x-2">
                          <Globe className="w-4 h-4 text-gray-500" />
                          <a href={place.contact.website} target="_blank" rel="noopener noreferrer" className="text-blue-600 text-sm hover:underline">
                            Visit Website
                          </a>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {(place.established || place.architecture) && (
              <div className="bg-white rounded-xl shadow-lg p-6">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Additional Details</h3>
                <div className="space-y-3">
                  {place.established && (
                    <div>
                      <span className="font-medium text-gray-800">Established:</span>
                      <span className="text-gray-700 ml-2">{place.established}</span>
                    </div>
                  )}
                  {place.architecture && (
                    <div>
                      <span className="font-medium text-gray-800">Architecture:</span>
                      <span className="text-gray-700 ml-2">{place.architecture}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}