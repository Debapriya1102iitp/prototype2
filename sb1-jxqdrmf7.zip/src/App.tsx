import React, { useState, useMemo } from 'react';
import Header from './components/Header';
import HomePage from './components/HomePage';
import PlaceDetail from './components/PlaceDetail';
import AddPlaceForm from './components/AddPlaceForm';
import PlaceCard from './components/PlaceCard';
import FilterBar from './components/FilterBar';
import { ReligiousPlace, FilterOptions } from './types';
import { religiousPlaces as initialPlaces } from './data/places';

type Page = 'home' | 'category' | 'place' | 'add';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedPlace, setSelectedPlace] = useState<ReligiousPlace | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [places, setPlaces] = useState<ReligiousPlace[]>(initialPlaces);
  const [filters, setFilters] = useState<FilterOptions>({
    category: '',
    state: '',
    searchTerm: ''
  });

  const filteredPlaces = useMemo(() => {
    return places.filter(place => {
      const matchesCategory = !filters.category || place.category === filters.category;
      const matchesState = !filters.state || place.location.state === filters.state;
      const matchesSearch = !filters.searchTerm || 
        place.name.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        place.location.city.toLowerCase().includes(filters.searchTerm.toLowerCase()) ||
        place.location.state.toLowerCase().includes(filters.searchTerm.toLowerCase());
      
      return matchesCategory && matchesState && matchesSearch;
    });
  }, [places, filters]);

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
    if (page === 'home') {
      setSelectedCategory('');
      setFilters(prev => ({ ...prev, category: '', state: '' }));
    }
  };

  const handleCategorySelect = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setFilters(prev => ({ ...prev, category: categoryId }));
    setCurrentPage('category');
  };

  const handlePlaceSelect = (place: ReligiousPlace) => {
    setSelectedPlace(place);
    setCurrentPage('place');
  };

  const handleAddPlace = (newPlace: Omit<ReligiousPlace, 'id'>) => {
    const place: ReligiousPlace = {
      ...newPlace,
      id: (places.length + 1).toString()
    };
    setPlaces(prev => [...prev, place]);
    setCurrentPage('home');
    alert('Thank you for contributing! Your submission has been added successfully.');
  };

  const handleSearchChange = (searchTerm: string) => {
    setFilters(prev => ({ ...prev, searchTerm }));
    if (searchTerm && currentPage === 'home') {
      setCurrentPage('category');
    }
  };

  const renderContent = () => {
    switch (currentPage) {
      case 'home':
        return (
          <HomePage
            places={places}
            onCategorySelect={handleCategorySelect}
            onPlaceSelect={handlePlaceSelect}
          />
        );
      
      case 'category':
        return (
          <div className="min-h-screen bg-gray-50">
            <FilterBar
              filters={filters}
              onFilterChange={setFilters}
              totalResults={filteredPlaces.length}
            />
            <div className="container mx-auto px-4 py-8">
              <div className="mb-8">
                <h1 className="text-3xl font-bold text-gray-800 mb-2">
                  {selectedCategory 
                    ? `${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}s` 
                    : 'All Religious Places'}
                </h1>
                <p className="text-gray-600">
                  {filteredPlaces.length} {filteredPlaces.length === 1 ? 'place' : 'places'} found
                </p>
              </div>
              
              {filteredPlaces.length === 0 ? (
                <div className="text-center py-16">
                  <div className="text-gray-400 text-6xl mb-4">🔍</div>
                  <h3 className="text-2xl font-semibold text-gray-700 mb-2">No places found</h3>
                  <p className="text-gray-600 mb-6">Try adjusting your search criteria or filters</p>
                  <button
                    onClick={() => setFilters({ category: '', state: '', searchTerm: '' })}
                    className="px-6 py-3 bg-orange-500 text-white rounded-lg hover:bg-orange-600 transition-colors"
                  >
                    Clear All Filters
                  </button>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                  {filteredPlaces.map(place => (
                    <PlaceCard
                      key={place.id}
                      place={place}
                      onSelect={handlePlaceSelect}
                    />
                  ))}
                </div>
              )}
            </div>
          </div>
        );
      
      case 'place':
        return selectedPlace ? (
          <PlaceDetail
            place={selectedPlace}
            onBack={() => setCurrentPage('category')}
          />
        ) : null;
      
      case 'add':
        return (
          <AddPlaceForm
            onBack={() => setCurrentPage('home')}
            onSubmit={handleAddPlace}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header
        onNavigate={handleNavigate}
        currentPage={currentPage}
        searchTerm={filters.searchTerm}
        onSearchChange={handleSearchChange}
      />
      {renderContent()}
    </div>
  );
}

export default App;