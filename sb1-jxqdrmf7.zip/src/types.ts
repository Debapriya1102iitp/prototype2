export interface ReligiousPlace {
  id: string;
  name: string;
  category: 'temple' | 'mosque' | 'gurdwara' | 'church';
  location: {
    address: string;
    city: string;
    state: string;
    pincode: string;
    coordinates?: {
      lat: number;
      lng: number;
    };
  };
  about: string;
  history: string;
  timings: {
    weekdays: string;
    weekends: string;
    specialDays?: string;
  };
  contact?: {
    phone?: string;
    email?: string;
    website?: string;
  };
  image: string;
  features: string[];
  established?: string;
  architecture?: string;
  festivals?: string[];
  addedBy?: string;
  addedDate?: string;
}

export interface FilterOptions {
  category: string;
  state: string;
  searchTerm: string;
}