import { ReligiousPlace } from '../types';

export const religiousPlaces: ReligiousPlace[] = [
  {
    id: '1',
    name: 'Meenakshi Amman Temple',
    category: 'temple',
    location: {
      address: 'Madurai Main, Madurai',
      city: 'Madurai',
      state: 'Tamil Nadu',
      pincode: '625001',
      coordinates: { lat: 9.9195, lng: 78.1199 }
    },
    about: 'The Meenakshi Temple is a historic Hindu temple located on the southern bank of the Vaigai River in the temple city of Madurai, Tamil Nadu, India.',
    history: 'The temple is dedicated to Meenakshi, a form of Parvati, and her consort, Sundareswarar, a form of Shiva. The temple complex covers 14 acres and has 14 gopurams (gateway towers), ranging from 45-50m in height. The tallest is the southern tower, 51.9 metres high.',
    timings: {
      weekdays: '5:00 AM - 12:30 PM, 4:00 PM - 9:30 PM',
      weekends: '5:00 AM - 12:30 PM, 4:00 PM - 10:00 PM',
      specialDays: 'During festivals: 4:00 AM - 11:00 PM'
    },
    contact: {
      phone: '+91-452-2345789',
      website: 'https://maduraimeenakshi.tn.gov.in'
    },
    image: 'https://images.pexels.com/photos/3580549/pexels-photo-3580549.jpeg',
    features: ['Gopurams', 'Hall of Thousand Pillars', 'Golden Lotus Tank', 'Art Gallery'],
    established: '6th century CE',
    architecture: 'Dravidian',
    festivals: ['Chithirai Festival', 'Navarathri', 'Karthigai Deepam']
  },
  {
    id: '2',
    name: 'Jama Masjid',
    category: 'mosque',
    location: {
      address: 'Jama Masjid Rd, Jama Masjid, Chandni Chowk',
      city: 'New Delhi',
      state: 'Delhi',
      pincode: '110006',
      coordinates: { lat: 28.6507, lng: 77.2334 }
    },
    about: 'Jama Masjid of Delhi is one of the largest mosques in India. It was built by the Mughal Emperor Shah Jahan between 1650 and 1656 at a cost of one million rupees.',
    history: 'The mosque was completed in 1656 AD. It is made of red sandstone and white marble, and consists of three great gateways, four angle towers and two 40m high minarets constructed of strips of red sandstone and white marble.',
    timings: {
      weekdays: '7:00 AM - 12:00 PM, 1:30 PM - 6:30 PM',
      weekends: '7:00 AM - 12:00 PM, 1:30 PM - 6:30 PM',
      specialDays: 'Closed during prayer times'
    },
    contact: {
      phone: '+91-11-2336-2334'
    },
    image: 'https://images.pexels.com/photos/3881104/pexels-photo-3881104.jpeg',
    features: ['Red Sandstone Architecture', 'White Marble Domes', 'Prayer Hall', 'Courtyard'],
    established: '1656 CE',
    architecture: 'Mughal',
    festivals: ['Eid ul-Fitr', 'Eid ul-Adha', 'Shab-e-Barat']
  },
  {
    id: '3',
    name: 'Golden Temple',
    category: 'gurdwara',
    location: {
      address: 'Golden Temple Rd, Atta Mandi, Katra Ahluwalia',
      city: 'Amritsar',
      state: 'Punjab',
      pincode: '143006',
      coordinates: { lat: 31.6200, lng: 74.8765 }
    },
    about: 'The Golden Temple, also known as Harmandir Sahib, is a gurdwara located in the city of Amritsar, Punjab, India. It is the holiest gurdwara and the most important pilgrimage site of Sikhism.',
    history: 'The Golden Temple was built by the fourth Sikh Guru, Guru Ram Das, in the 16th century. The temple was destroyed several times by Afghan and Mughal invaders and was rebuilt each time by the Sikhs.',
    timings: {
      weekdays: '24 hours (Open all day)',
      weekends: '24 hours (Open all day)',
      specialDays: '24 hours (Open all day)'
    },
    contact: {
      phone: '+91-183-2553954',
      website: 'https://sgpc.net'
    },
    image: 'https://images.pexels.com/photos/11447982/pexels-photo-11447982.jpeg',
    features: ['Sarovar (Holy Pool)', 'Langar Hall', 'Akal Takht', 'Museum'],
    established: '1577 CE',
    architecture: 'Sikh',
    festivals: ['Guru Nanak Jayanti', 'Baisakhi', 'Diwali', 'Holi']
  },
  {
    id: '4',
    name: 'St. Thomas Cathedral',
    category: 'church',
    location: {
      address: 'Veer Nariman Rd, Fort',
      city: 'Mumbai',
      state: 'Maharashtra',
      pincode: '400001',
      coordinates: { lat: 18.9322, lng: 72.8264 }
    },
    about: 'St. Thomas Cathedral is an Anglican cathedral in Mumbai, India. It is the oldest British-era church in Mumbai and is the cathedral church of the Diocese of Bombay.',
    history: 'The cathedral was begun in 1672 and completed in 1718. It was the first Anglican church in Bombay and was built in the typical English church style with a blend of colonial architecture.',
    timings: {
      weekdays: '6:00 AM - 7:00 PM',
      weekends: '6:00 AM - 8:00 PM',
      specialDays: 'Sunday services: 7:00 AM, 8:30 AM, 6:00 PM'
    },
    contact: {
      phone: '+91-22-2266-0418',
      email: 'stthomaschurch@gmail.com'
    },
    image: 'https://images.pexels.com/photos/12345678/pexels-photo-12345678.jpeg',
    features: ['Colonial Architecture', 'Stained Glass Windows', 'Bell Tower', 'Graveyard'],
    established: '1718 CE',
    architecture: 'British Colonial',
    festivals: ['Christmas', 'Easter', 'Good Friday', 'Harvest Festival']
  },
  {
    id: '5',
    name: 'Vaishno Devi Temple',
    category: 'temple',
    location: {
      address: 'Trikuta Mountains, Katra',
      city: 'Katra',
      state: 'Jammu and Kashmir',
      pincode: '182301',
      coordinates: { lat: 33.0330, lng: 74.9500 }
    },
    about: 'Vaishno Devi Temple is one of the holiest Hindu temples, dedicated to Vaishno Devi, situated in the hills of Vaishno Devi, Jammu and Kashmir, India.',
    history: 'The temple has been a beacon of faith and fulfillment for millions of devotees from all over the world. The legend of Mata Vaishno Devi dates back to the Puranic times.',
    timings: {
      weekdays: '24 hours (Open all day)',
      weekends: '24 hours (Open all day)',
      specialDays: '24 hours (Open all day)'
    },
    contact: {
      phone: '+91-1991-232001',
      website: 'https://maavaishnodevi.org'
    },
    image: 'https://images.pexels.com/photos/15031996/pexels-photo-15031996.jpeg',
    features: ['Cave Temple', 'Helicopter Service', 'Yatra Registration', 'Pilgrimage Path'],
    established: 'Ancient times',
    architecture: 'Cave Temple',
    festivals: ['Navarathri', 'Diwali', 'Dussehra', 'Janmashtami']
  },
  {
    id: '6',
    name: 'Ajmer Sharif Dargah',
    category: 'mosque',
    location: {
      address: 'Dargah Bazaar, Ajmer',
      city: 'Ajmer',
      state: 'Rajasthan',
      pincode: '305001',
      coordinates: { lat: 26.4499, lng: 74.6399 }
    },
    about: 'Ajmer Sharif Dargah is a Sufi shrine of the revered saint, Moinuddin Chishti, located at Ajmer, Rajasthan, India.',
    history: 'The shrine is visited by more than 125,000 pilgrims daily. The saint came to Ajmer from Persia in 1192 CE and died in 1236 CE. The shrine was built by Humayun.',
    timings: {
      weekdays: '4:00 AM - 2:00 AM (next day)',
      weekends: '4:00 AM - 2:00 AM (next day)',
      specialDays: 'Urs: 24 hours for 6 days'
    },
    contact: {
      phone: '+91-145-2627454',
      website: 'https://ajmersharif.org'
    },
    image: 'https://images.pexels.com/photos/17071449/pexels-photo-17071449.jpeg',
    features: ['Mazar Sharif', 'Jama Masjid', 'Langar Khana', 'Pilgrim Rest House'],
    established: '13th century CE',
    architecture: 'Indo-Islamic',
    festivals: ['Urs Sharif', 'Eid ul-Fitr', 'Eid ul-Adha']
  }
];

export const categories = [
  { id: 'temple', name: 'Temples', icon: '🕌', color: 'orange' },
  { id: 'mosque', name: 'Mosques', icon: '🕌', color: 'green' },
  { id: 'gurdwara', name: 'Gurdwaras', icon: '🏛️', color: 'blue' },
  { id: 'church', name: 'Churches', icon: '⛪', color: 'purple' }
];

export const states = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Delhi',
  'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jammu and Kashmir', 'Jharkhand',
  'Karnataka', 'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya',
  'Mizoram', 'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
  'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal'
];